//=========================================================================
//
// TASKFARM.HPP
//
//=========================================================================
#ifndef TASKFARM_HPP
//=========================================================================
#include "x_files.hpp"
#include "x_threads.hpp"
#include "CommandLine.hpp"
//=========================================================================

class task_farm_link;
class task_farm_request;
class task_farm_thread;
class task_farm_dispatcher;

//=========================================================================

class task_farm_link
{
public:
    task_farm_link();
    ~task_farm_link();

    xbool IsEmpty   ( void );
    void  Clear     ( void );
    void  SetOwner  ( void* apOwner );
    void* GetOwner  ( void );

    task_farm_link* GetNext( void );
    task_farm_link* GetPrev( void );

    void InsertAtHead( task_farm_link& Link );
    void InsertAtTail( task_farm_link& Link );
    void Remove( void );

    task_farm_link* PopHead( void );
    task_farm_link* PopTail( void );

private:

    void*       pOwner;
    task_farm_link* pNext;
    task_farm_link* pPrev;
};

//=========================================================================

class task_farm_request
{
public:
                    task_farm_request();
    virtual         ~task_farm_request();
    virtual void    Execute( void )=0;
    void            AddToTailOfList    ( task_farm_link& Chain );
    void            RemoveFromList     ( void );

public:
    
    enum thread_task_state 
    {
        STATE_UNINITIALIZED=0,
        STATE_POSTED_TO_DISPATCHER,
        STATE_POSTED_TO_PROCESSOR,
        STATE_EXECUTING,
        STATE_COMPLETED
    };

    task_farm_link          m_Link;
    s32                 m_iThread;
    thread_task_state   m_State;
    xtick               m_ExecutionTime;
    s32                 m_ExecutionGroup;
};

//=========================================================================

class task_farm_thread
{
public:

    task_farm_thread() {};
    ~task_farm_thread() {};

    void Init       ( void );
    void Kill       ( void ){};
    void Execute    ( void );

private:

    // Initialized by dispatcher
    s32                     m_iThread;
    xmesgq*                 m_pMsgQ;
    task_farm_dispatcher*   m_pDispatcher;
    xthread*                m_pThread;
    task_farm_request*      m_pCurrentTask;

    enum task_farm_thread_state
    {
        STATE_INIT=0,
        STATE_WAITING_FOR_TASK,
        STATE_EXECUTING_TASK,
        STATE_REPORTING_TASK_COMPLETE,
        STATE_SHUTDOWN,
    };
    task_farm_thread_state m_State;

    friend task_farm_dispatcher;
};

//=========================================================================

class task_farm_dispatcher
{
public:

    task_farm_dispatcher() {m_bInitialized=0;};
    ~task_farm_dispatcher() {};

    void Init       ( s32 nThreads );
    void Kill       ( void );
    void Execute    ( void );

    void PostTask   ( task_farm_request* pTask );
    void StartNewExecutionGroup( void );
    void ReportCompletedTask(  task_farm_request* pTask );

    // Blocks until all outstanding tasks are completed
    void FlushTasks ( void );

    xbool ProcessMsgs           ( void );
    void  ProcessMsg            ( task_farm_request* pTask );
    void  QueueRequestedTask    ( task_farm_request* pTask );
    void  QueueCompletedTask    ( task_farm_request* pTask );
    void  ServiceRequestQueue   ( void );

private:

    // Processor threads
    #define MAX_TASK_FARM_THREADS   8
    s32                m_nProcessorThreads;
    task_farm_thread   m_ProcessorThread[MAX_TASK_FARM_THREADS];

    // Message Queue
    xmesgq*     m_pMsgQ;
    xthread*    m_pThread;

    // Chains
    task_farm_link  m_RequestList;
    task_farm_link  m_CompletedList;

    // State info
    xbool       m_bInitialized;
    s32         m_nTasksReceived;
    s32         m_nTasksDispatched;
    s32         m_nTasksCompleted;

    enum task_farm_dispatcher_state
    {
        STATE_INIT=0,
        STATE_WAITING_FOR_TASK,
        STATE_PROCESSING_TASK_REQUEST,
        STATE_PROCESSING_COMPLETED_TASK,
        STATE_SHUTDOWN,
        STATE_KILL,
    };
    task_farm_dispatcher_state m_State;

    // Execution group
    s32         m_ExecutionGroupSeq;
};

//=========================================================================

#include "TaskFarm_Inline.hpp"

//=========================================================================

extern task_farm_dispatcher g_TaskFarmDispatcher;

//=========================================================================
#endif //TASKFARM_HPP
//=========================================================================
