//=========================================================================
//
// TASKFARM_THREAD.CPP
//
//=========================================================================
#include "TaskFarm.hpp"
//=========================================================================

//=========================================================================
// TASK_FARM_THREAD
//=========================================================================

void task_farm_thread::Init( void )
{
    m_State = task_farm_thread::STATE_INIT;
    m_pCurrentTask = NULL;
}

//=========================================================================

void task_farm_thread::Execute( void )
{

    HANDLE T = GetCurrentThread();
    SetThreadPriority(T,THREAD_PRIORITY_ABOVE_NORMAL);
    //SetThreadPriority(T,THREAD_PRIORITY_HIGHEST);
    s32 P = GetThreadPriority(T);
    TASK_FARM_LOG("Thread %d initialized at priority %d.\n",m_iThread,P);

    while( 1 )
    {
        TASK_FARM_LOG("Thread %d waiting for task.\n",m_iThread);

        // Block for a new task
        m_State = task_farm_thread::STATE_WAITING_FOR_TASK;
        m_pCurrentTask = (task_farm_request*)m_pMsgQ->Recv(MQ_BLOCK);
        TASK_FARM_LOG("Thread %d task received %08X.\n",m_iThread,(u32)m_pCurrentTask);


        m_State = task_farm_thread::STATE_EXECUTING_TASK;

        // If NULL Task then exit loop and enter delay
        if( m_pCurrentTask==NULL )
            break;

        // Process the task
        TASK_FARM_LOG("Thread %d starting task\n",m_iThread);
        m_pCurrentTask->m_State = task_farm_request::STATE_EXECUTING;
        m_pCurrentTask->m_ExecutionTime = x_GetTime();
        m_pCurrentTask->Execute();
        m_pCurrentTask->m_ExecutionTime = x_GetTime() - m_pCurrentTask->m_ExecutionTime;
        TASK_FARM_LOG("Thread %d reporting completed task %08X\n",m_iThread,(u32)m_pCurrentTask);

        m_State = task_farm_thread::STATE_REPORTING_TASK_COMPLETE;
        m_pDispatcher->ReportCompletedTask( m_pCurrentTask );
        m_pCurrentTask = NULL;
    }

    m_State = task_farm_thread::STATE_SHUTDOWN;
}

//=========================================================================
